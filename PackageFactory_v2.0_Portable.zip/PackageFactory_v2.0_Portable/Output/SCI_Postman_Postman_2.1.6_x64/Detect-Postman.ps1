<#
.SYNOPSIS
    Postman - Intune Detection Script
.DESCRIPTION
    Detects if Postman is installed using centralized registry pattern (Multi-Tenant ready)
.NOTES
    Author: Christoph Ramböck (c@ramboeck.it)
    Version: 2.1.6
    Created: 2025-11-01
    
    Detection Pattern: HKLM:\SOFTWARE\{CompanyPrefix}_IntuneAppInstall\Apps\{AppIdentifier}
    App Identifier: Postman-Postman-2.1.6-EN-01-x64
#>

try {
    # Centralized detection key pattern (Multi-Tenant / MSP ready)
    $appIdentifier = "Postman-Postman-2.1.6-EN-01-x64"
    $detectionKey = "HKLM:\SOFTWARE\SCI_IntuneAppInstall\Apps\$appIdentifier"

    if (Test-Path -Path $detectionKey) {
        # Read all metadata
        $displayName = Get-ItemPropertyValue -Path $detectionKey -Name "DisplayName" -ErrorAction SilentlyContinue
        $displayVersion = Get-ItemPropertyValue -Path $detectionKey -Name "DisplayVersion" -ErrorAction SilentlyContinue
        $installDate = Get-ItemPropertyValue -Path $detectionKey -Name "InstallDate" -ErrorAction SilentlyContinue
        $publisher = Get-ItemPropertyValue -Path $detectionKey -Name "Publisher" -ErrorAction SilentlyContinue
        $scriptVersion = Get-ItemPropertyValue -Path $detectionKey -Name "ScriptVersion" -ErrorAction SilentlyContinue
        $installedBy = Get-ItemPropertyValue -Path $detectionKey -Name "InstalledBy" -ErrorAction SilentlyContinue
        $installed = Get-ItemPropertyValue -Path $detectionKey -Name "Installed" -ErrorAction SilentlyContinue

        # Check if marked as installed
        if ($installed -ne "Y") {
            Write-Output "Postman registry key exists but marked as uninstalled (Installed=$installed)"
            exit 1
        }

        # Verify version match
        if ($displayVersion -eq "2.1.6") {
            Write-Output "$displayName detected (Version: $displayVersion, Installed: $installDate, Publisher: $publisher, ScriptVer: $scriptVersion)"
            exit 0
        }
        else {
            Write-Output "Postman found but wrong version: $displayVersion (Expected: 2.1.6)"
            exit 1
        }
    }

    Write-Output "Postman not detected - Registry key not found: $detectionKey"
    exit 1
}
catch {
    Write-Output "Detection error: $($_.Exception.Message)"
    exit 1
}

