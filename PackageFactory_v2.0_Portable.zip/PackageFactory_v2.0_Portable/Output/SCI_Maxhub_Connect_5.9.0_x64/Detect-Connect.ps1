<#
.SYNOPSIS
    Connect - Intune Detection Script
.DESCRIPTION
    Detects if Connect is installed using centralized registry pattern (Multi-Tenant ready)
.NOTES
    Author: Christoph Ramböck (c@ramboeck.it)
    Version: 5.9.0
    Created: 2025-11-02
    
    Detection Pattern: HKLM:\SOFTWARE\{CompanyPrefix}_IntuneAppInstall\Apps\{AppIdentifier}
    App Identifier: Maxhub-Connect-5.9.0-EN-01-x64
#>

try {
    # Centralized detection key pattern (Multi-Tenant / MSP ready)
    $appIdentifier = "Maxhub-Connect-5.9.0-EN-01-x64"
    $detectionKey = "HKLM:\SOFTWARE\SCI_IntuneAppInstall\Apps\$appIdentifier"

    if (Test-Path -Path $detectionKey) {
        # Read all metadata
        $displayName = Get-ItemPropertyValue -Path $detectionKey -Name "DisplayName" -ErrorAction SilentlyContinue
        $displayVersion = Get-ItemPropertyValue -Path $detectionKey -Name "DisplayVersion" -ErrorAction SilentlyContinue
        $installDate = Get-ItemPropertyValue -Path $detectionKey -Name "InstallDate" -ErrorAction SilentlyContinue
        $publisher = Get-ItemPropertyValue -Path $detectionKey -Name "Publisher" -ErrorAction SilentlyContinue
        $scriptVersion = Get-ItemPropertyValue -Path $detectionKey -Name "ScriptVersion" -ErrorAction SilentlyContinue
        $installedBy = Get-ItemPropertyValue -Path $detectionKey -Name "InstalledBy" -ErrorAction SilentlyContinue
        $installed = Get-ItemPropertyValue -Path $detectionKey -Name "Installed" -ErrorAction SilentlyContinue

        # Check if marked as installed
        if ($installed -ne "Y") {
            Write-Output "Connect registry key exists but marked as uninstalled (Installed=$installed)"
            exit 1
        }

        # Verify version match
        if ($displayVersion -eq "5.9.0") {
            Write-Output "$displayName detected (Version: $displayVersion, Installed: $installDate, Publisher: $publisher, ScriptVer: $scriptVersion)"
            exit 0
        }
        else {
            Write-Output "Connect found but wrong version: $displayVersion (Expected: 5.9.0)"
            exit 1
        }
    }

    Write-Output "Connect not detected - Registry key not found: $detectionKey"
    exit 1
}
catch {
    Write-Output "Detection error: $($_.Exception.Message)"
    exit 1
}

