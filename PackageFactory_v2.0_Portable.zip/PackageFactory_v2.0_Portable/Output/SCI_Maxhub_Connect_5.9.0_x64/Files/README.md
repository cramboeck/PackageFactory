# Installation Files

## Required Files

### MAXHUBConnect_Win_5.9.0.3846.msi
**Action:** Download installer and place here

### Config/ (Optional)
**Action:** Add configuration files if needed

---

**© 2025 Ramböck IT**
