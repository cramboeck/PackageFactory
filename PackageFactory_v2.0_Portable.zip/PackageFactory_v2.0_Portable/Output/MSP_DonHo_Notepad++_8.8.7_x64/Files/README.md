# Installation Files

## Required Files

### npp.8.8.7.Installer.x64.exe
**Action:** Download installer and place here

### Config/ (Optional)
**Action:** Add configuration files if needed

---

**© 2025 Ramböck IT**
