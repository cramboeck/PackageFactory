<#
.SYNOPSIS
    Notepad++ - Intune Detection Script
.DESCRIPTION
    Detects if Notepad++ is installed using centralized registry pattern (Multi-Tenant ready)
.NOTES
    Author: Christoph Ramböck (c@ramboeck.it)
    Version: 8.8.7
    Created: 2025-11-02
    
    Detection Pattern: HKLM:\SOFTWARE\{CompanyPrefix}_IntuneAppInstall\Apps\{AppIdentifier}
    App Identifier: DonHo-Notepad++-8.8.7-EN-01-x64
#>

try {
    # Centralized detection key pattern (Multi-Tenant / MSP ready)
    $appIdentifier = "DonHo-Notepad++-8.8.7-EN-01-x64"
    $detectionKey = "HKLM:\SOFTWARE\MSP_IntuneAppInstall\Apps\$appIdentifier"

    if (Test-Path -Path $detectionKey) {
        # Read all metadata
        $displayName = Get-ItemPropertyValue -Path $detectionKey -Name "DisplayName" -ErrorAction SilentlyContinue
        $displayVersion = Get-ItemPropertyValue -Path $detectionKey -Name "DisplayVersion" -ErrorAction SilentlyContinue
        $installDate = Get-ItemPropertyValue -Path $detectionKey -Name "InstallDate" -ErrorAction SilentlyContinue
        $publisher = Get-ItemPropertyValue -Path $detectionKey -Name "Publisher" -ErrorAction SilentlyContinue
        $scriptVersion = Get-ItemPropertyValue -Path $detectionKey -Name "ScriptVersion" -ErrorAction SilentlyContinue
        $installedBy = Get-ItemPropertyValue -Path $detectionKey -Name "InstalledBy" -ErrorAction SilentlyContinue
        $installed = Get-ItemPropertyValue -Path $detectionKey -Name "Installed" -ErrorAction SilentlyContinue

        # Check if marked as installed
        if ($installed -ne "Y") {
            Write-Output "Notepad++ registry key exists but marked as uninstalled (Installed=$installed)"
            exit 1
        }

        # Verify version match
        if ($displayVersion -eq "8.8.7") {
            Write-Output "$displayName detected (Version: $displayVersion, Installed: $installDate, Publisher: $publisher, ScriptVer: $scriptVersion)"
            exit 0
        }
        else {
            Write-Output "Notepad++ found but wrong version: $displayVersion (Expected: 8.8.7)"
            exit 1
        }
    }

    Write-Output "Notepad++ not detected - Registry key not found: $detectionKey"
    exit 1
}
catch {
    Write-Output "Detection error: $($_.Exception.Message)"
    exit 1
}

